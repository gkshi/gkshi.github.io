(function (root) {
    let MAP = {};

    root.GAME.MAP = MAP;
})(this);
