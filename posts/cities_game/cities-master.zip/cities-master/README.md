## Cities the game

Yandex SHRI Minsk 2018 task #3

demo: [http://gkshi.ucoz.net/cities](http://gkshi.ucoz.net/cities)